configure({
  configs: [
    './test.js'
  ]
});