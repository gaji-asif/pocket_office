configure({
  configs: [
    './../../../../core/config/bolt/demo.js'
  ]
});
