<?php
return [
    'app_name' => env('GMAIL_APP_NAME', ''),
    'client_id' => env('GMAIL_CLIENT_ID', '953239126419-pn2j6fdb7t9u6jckg33r3t946in54bku.apps.googleusercontent.com'),
    'client_secret' => env('GMAIL_SECRET', 'XuY0nlbPlL-wWGABBrEGijbv'),
    'project_id' => env('GMAIL_PROJECT_ID', 'dev-01-xoom-1597157506511'),
    'redirect_uri' => env('GMAIL_REDIRECT_URI', 'http://localhost/xactbid/mail-react-app/api/auth.php'),
];
